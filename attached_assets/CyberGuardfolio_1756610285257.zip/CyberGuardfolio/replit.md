# Overview

This is a cybersecurity professional portfolio website for Nawal Wahdan, built as a Flask web application. The portfolio showcases cybersecurity expertise, specializing in penetration testing and vulnerability analysis. The site features a modern, cyberpunk-themed design with terminal-style elements and interactive components to reflect the cybersecurity domain.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Template Engine**: Jinja2 templating with Flask's built-in template system
- **Base Template Pattern**: Uses template inheritance with `base.html` as the foundation and `index.html` extending it
- **Styling Framework**: Bootstrap 5.3.0 for responsive grid system and components
- **Icon Library**: Font Awesome 6.4.0 for cybersecurity-themed icons
- **Typography**: Google Fonts (Orbitron for monospace/terminal effects, Rajdhani for primary text)
- **Theme**: Cyberpunk/hacker aesthetic with dark backgrounds, neon colors, and terminal-style elements

## Backend Architecture
- **Framework**: Flask (Python web framework)
- **Application Structure**: Simple single-file application (`app.py`) with minimal routing
- **Session Management**: Flask sessions with configurable secret key
- **Error Handling**: Custom 404 and 500 error handlers that redirect to the main page
- **Static File Serving**: Flask's built-in static file serving for CSS, assets, and downloadable files

## Routing Strategy
- **Single Page Application**: Main content served through the root route (`/`)
- **File Download**: Dedicated route (`/download-cv`) for CV download functionality
- **Error Resilience**: All errors gracefully redirect to the main portfolio page

## Security Considerations
- **Environment Variables**: Session secret key configurable via environment variables
- **File Security**: CV download route includes proper file existence validation
- **Error Handling**: Prevents information disclosure through custom error pages

## Deployment Configuration
- **Host Configuration**: Set to listen on all interfaces (0.0.0.0)
- **Port**: Configured for port 5000
- **Debug Mode**: Enabled for development (should be disabled in production)
- **Entry Points**: Both `app.py` and `main.py` can serve as application entry points

# External Dependencies

## Frontend Dependencies
- **Bootstrap 5.3.0**: CSS framework loaded via CDN for responsive design components
- **Font Awesome 6.4.0**: Icon library loaded via CDN for cybersecurity-themed iconography
- **Google Fonts**: Typography service for Orbitron and Rajdhani font families

## Backend Dependencies
- **Flask**: Python web framework for application core
- **Python Standard Library**: Uses `os` for environment variable access and `logging` for application logging

## Static Assets
- **Custom CSS**: `style.css` containing cyberpunk theme styling with CSS custom properties
- **CV File**: PDF resume stored in `/static/assets/` directory for download functionality
- **File Structure**: Standard Flask static file organization for assets, CSS, and downloadable content

## Development Tools
- **Logging**: Python's built-in logging module configured for debug-level output
- **Template System**: Flask's integrated Jinja2 templating engine for dynamic content rendering