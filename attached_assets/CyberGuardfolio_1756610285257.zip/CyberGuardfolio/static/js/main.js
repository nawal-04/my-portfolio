/**
 * Cybersecurity Portfolio JavaScript
 * Author: Nawal Wahdan
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initNavigation();
    initAnimations();
    initTypingEffect();
    initScrollEffects();
    initContactForm();
    
    console.log('🔒 Portfolio initialized successfully');
});

/**
 * Navigation functionality
 */
function initNavigation() {
    const navbar = document.querySelector('.cyber-nav');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Smooth scrolling for navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href.startsWith('#')) {
                e.preventDefault();
                const target = document.querySelector(href);
                
                if (target) {
                    const offsetTop = target.offsetTop - 80;
                    window.scrollTo({
                        top: offsetTop,
                        behavior: 'smooth'
                    });
                    
                    // Close mobile menu if open
                    const navbarCollapse = document.querySelector('.navbar-collapse');
                    if (navbarCollapse.classList.contains('show')) {
                        bootstrap.Collapse.getInstance(navbarCollapse).hide();
                    }
                }
            }
        });
    });
    
    // Navbar background on scroll
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.style.background = 'rgba(10, 10, 10, 0.98)';
        } else {
            navbar.style.background = 'rgba(10, 10, 10, 0.95)';
        }
    });
    
    // Active link highlighting
    window.addEventListener('scroll', updateActiveNavLink);
}

/**
 * Update active navigation link based on scroll position
 */
function updateActiveNavLink() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link[href^="#"]');
    
    let current = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 100;
        const sectionHeight = section.clientHeight;
        
        if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
}

/**
 * Initialize scroll-triggered animations
 */
function initAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const element = entry.target;
                
                // Add animation classes based on element type
                if (element.classList.contains('skill-category')) {
                    element.style.animationDelay = `${Math.random() * 0.3}s`;
                    element.classList.add('animate-in');
                } else if (element.classList.contains('project-card')) {
                    element.style.animationDelay = `${Math.random() * 0.3}s`;
                    element.classList.add('animate-in');
                } else if (element.classList.contains('timeline-item')) {
                    element.style.animationDelay = `${Math.random() * 0.2}s`;
                    element.classList.add('animate-left');
                } else if (element.classList.contains('stat-item')) {
                    element.style.animationDelay = `${Math.random() * 0.2}s`;
                    element.classList.add('animate-in');
                } else {
                    element.classList.add('animate-in');
                }
                
                observer.unobserve(element);
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animateElements = document.querySelectorAll(
        '.skill-category, .project-card, .timeline-item, .stat-item, .contact-item'
    );
    
    animateElements.forEach(element => {
        observer.observe(element);
    });
}

/**
 * Terminal typing effect
 */
function initTypingEffect() {
    const commandElement = document.querySelector('.command.typing');
    if (!commandElement) return;
    
    const commands = [
        'whoami',
        'cat skills.txt',
        'ls projects/',
        'grep -r "security"',
        './penetration_test.py'
    ];
    
    let currentCommandIndex = 0;
    
    function typeCommand() {
        const command = commands[currentCommandIndex];
        commandElement.textContent = '';
        commandElement.style.width = '0';
        
        setTimeout(() => {
            commandElement.textContent = command;
            commandElement.style.width = 'auto';
            
            currentCommandIndex = (currentCommandIndex + 1) % commands.length;
            
            // Schedule next command
            setTimeout(typeCommand, 3000);
        }, 500);
    }
    
    // Start typing effect after initial delay
    setTimeout(typeCommand, 2000);
}

/**
 * Scroll effects and parallax
 */
function initScrollEffects() {
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const rate = scrolled * -0.5;
        
        // Parallax effect for hero background
        const heroElement = document.querySelector('.hero-bg');
        if (heroElement) {
            heroElement.style.transform = `translateY(${rate}px)`;
        }
        
        // Update skill progress bars if visible
        updateSkillBars();
    });
}

/**
 * Update skill progress visualization
 */
function updateSkillBars() {
    const skillItems = document.querySelectorAll('.skill-item');
    
    skillItems.forEach(item => {
        const rect = item.getBoundingClientRect();
        const isVisible = rect.top < window.innerHeight && rect.bottom > 0;
        
        if (isVisible && !item.classList.contains('animated')) {
            item.classList.add('animated');
            
            // Add a subtle glow effect when skill comes into view
            setTimeout(() => {
                item.style.transition = 'all 0.3s ease';
                item.style.boxShadow = '0 0 15px rgba(0, 212, 255, 0.2)';
                
                setTimeout(() => {
                    item.style.boxShadow = '';
                }, 1000);
            }, Math.random() * 500);
        }
    });
}

/**
 * Contact form functionality
 */
function initContactForm() {
    // Add click tracking for contact methods
    const contactLinks = document.querySelectorAll('.contact-link');
    
    contactLinks.forEach(link => {
        link.addEventListener('click', function() {
            const type = this.href.includes('mailto') ? 'email' : 
                        this.href.includes('tel') ? 'phone' : 'link';
            
            console.log(`📞 Contact initiated: ${type}`);
            
            // Add visual feedback
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
        });
    });
    
    // Download CV tracking
    const downloadBtn = document.querySelector('a[href="/download-cv"]');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', function() {
            console.log('📄 CV download initiated');
            
            // Add visual feedback
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
        });
    }
}

/**
 * Utility function to add glitch effect to elements
 */
function addGlitchEffect(element, duration = 2000) {
    element.classList.add('glitch');
    
    setTimeout(() => {
        element.classList.remove('glitch');
    }, duration);
}

/**
 * Easter egg - Konami code
 */
(function() {
    const konamiCode = [
        'ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown',
        'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight',
        'KeyB', 'KeyA'
    ];
    
    let userInput = [];
    
    document.addEventListener('keydown', function(e) {
        userInput.push(e.code);
        
        if (userInput.length > konamiCode.length) {
            userInput.shift();
        }
        
        if (userInput.join(',') === konamiCode.join(',')) {
            activateHackerMode();
            userInput = [];
        }
    });
    
    function activateHackerMode() {
        console.log('🎮 Hacker mode activated!');
        
        // Add matrix rain effect
        createMatrixRain();
        
        // Add glitch to all text elements
        const textElements = document.querySelectorAll('h1, h2, h3, .hero-title');
        textElements.forEach(el => addGlitchEffect(el, 5000));
        
        setTimeout(() => {
            document.querySelector('.matrix-rain')?.remove();
        }, 10000);
    }
    
    function createMatrixRain() {
        const canvas = document.createElement('canvas');
        canvas.className = 'matrix-rain';
        canvas.style.position = 'fixed';
        canvas.style.top = '0';
        canvas.style.left = '0';
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        canvas.style.zIndex = '9999';
        canvas.style.pointerEvents = 'none';
        canvas.style.background = 'rgba(0, 0, 0, 0.1)';
        
        document.body.appendChild(canvas);
        
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        
        const chars = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
        const charArray = chars.split('');
        const fontSize = 14;
        const columns = canvas.width / fontSize;
        const drops = Array(Math.floor(columns)).fill(1);
        
        function draw() {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            ctx.fillStyle = '#00ff88';
            ctx.font = `${fontSize}px monospace`;
            
            drops.forEach((y, index) => {
                const char = charArray[Math.floor(Math.random() * charArray.length)];
                const x = index * fontSize;
                
                ctx.fillText(char, x, y * fontSize);
                
                if (y * fontSize > canvas.height && Math.random() > 0.975) {
                    drops[index] = 0;
                }
                drops[index]++;
            });
        }
        
        const interval = setInterval(draw, 35);
        
        setTimeout(() => {
            clearInterval(interval);
        }, 10000);
    }
})();

/**
 * Preloader (if needed)
 */
window.addEventListener('load', function() {
    // Hide preloader if exists
    const preloader = document.querySelector('.preloader');
    if (preloader) {
        preloader.style.opacity = '0';
        setTimeout(() => {
            preloader.style.display = 'none';
        }, 300);
    }
    
    // Initialize performance monitoring
    if ('performance' in window) {
        const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
        console.log(`⚡ Page loaded in ${loadTime}ms`);
    }
});

/**
 * Translation functionality
 */
let isArabic = false;

const translations = {
    english: {
        text: `I proactively uncover and help remediate security vulnerabilities by thinking like an adversary. 
               My passion lies in <span class="highlight">ethical hacking</span>, 
               <span class="highlight">vulnerability assessment</span>, and leveraging cutting-edge technology 
               to build more secure systems.`,
        button: 'عربي'
    },
    arabic: {
        text: `أكتشف بشكل استباقي وأساعد في معالجة الثغرات الأمنية من خلال التفكير مثل الخصم. 
               شغفي يكمن في <span class="highlight">الاختراق الأخلاقي</span>، 
               <span class="highlight">تقييم الثغرات الأمنية</span>، واستخدام التكنولوجيا المتطورة 
               لبناء أنظمة أكثر أماناً.`,
        button: 'English'
    }
};

function toggleTranslation() {
    const descriptionElement = document.getElementById('hero-description');
    const translateBtn = document.getElementById('translate-btn');
    
    if (!descriptionElement || !translateBtn) return;
    
    isArabic = !isArabic;
    
    const currentTranslation = isArabic ? translations.arabic : translations.english;
    
    // Add fade effect
    descriptionElement.style.opacity = '0';
    
    setTimeout(() => {
        descriptionElement.innerHTML = currentTranslation.text;
        translateBtn.innerHTML = `<i class="fas fa-language me-1"></i>${currentTranslation.button}`;
        
        // Set text direction for Arabic
        if (isArabic) {
            descriptionElement.style.direction = 'rtl';
            descriptionElement.style.textAlign = 'right';
        } else {
            descriptionElement.style.direction = 'ltr';
            descriptionElement.style.textAlign = 'left';
        }
        
        descriptionElement.style.opacity = '1';
    }, 300);
}

/**
 * Service Worker registration (for PWA capabilities)
 */
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        // Uncomment to enable service worker
        // navigator.serviceWorker.register('/sw.js')
        //     .then(registration => console.log('🔧 SW registered'))
        //     .catch(error => console.log('❌ SW registration failed'));
    });
}
