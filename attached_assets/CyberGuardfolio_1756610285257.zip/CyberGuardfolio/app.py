import os
from flask import Flask, render_template, send_file, abort
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")

@app.route('/')
def index():
    """Main portfolio page"""
    return render_template('index.html')

@app.route('/download-cv')
def download_cv():
    """Download CV/Resume"""
    try:
        return send_file('static/assets/cv.pdf', as_attachment=True, download_name='Nawal_Wahdan_CV.pdf')
    except FileNotFoundError:
        abort(404)

@app.errorhandler(404)
def not_found_error(error):
    return render_template('index.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('index.html'), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
